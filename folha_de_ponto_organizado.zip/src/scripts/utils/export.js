/* ============================================================
   export.js — Exportação PDF & Excel · Nova Telecom
   ============================================================ */

import { showToast } from './helpers.js';

/**
 * Exporta um elemento HTML para PDF usando a impressão nativa do navegador.
 * Para PDF real, integrar com biblioteca como jsPDF ou API de backend.
 * @param {string} elementId
 * @param {string} _filename — reservado para integração futura
 */
export function exportarPDF(elementId, _filename = 'relatorio.pdf') {
  const el = document.getElementById(elementId);
  if (!el) { showToast('Elemento não encontrado para exportar.', 'error'); return; }

  const original = document.body.innerHTML;
  document.body.innerHTML = el.outerHTML;
  window.print();
  document.body.innerHTML = original;
  window.location.reload();
}

/**
 * Exporta um array de objetos para CSV (compatível com Excel).
 * @param {Array<Object>} data
 * @param {string} filename
 */
export function exportarExcel(data, filename = 'relatorio.csv') {
  if (!data?.length) { showToast('Nenhum dado para exportar.', 'warning'); return; }

  const headers = Object.keys(data[0]);
  const csv = [
    headers.join(';'),
    ...data.map(row => headers.map(h => `"${row[h] ?? ''}"`).join(';')),
  ].join('\n');

  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = Object.assign(document.createElement('a'), { href: url, download: filename });
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  showToast('Arquivo exportado com sucesso!', 'success');
}
